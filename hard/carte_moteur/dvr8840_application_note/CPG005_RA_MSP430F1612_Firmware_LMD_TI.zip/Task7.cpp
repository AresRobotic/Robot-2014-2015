//******************************************************************************
//  Jose I Quinones
//  Texas Instruments Inc.
//  July 2010
//  Built with IAR Embedded Workbench Version: 3.42A
//******************************************************************************
#include "Config.h"

void Task7(void)
{
StatusLED += 1;
if (!StatusLED)
    {
    P6OUT ^= StatusLEDPin;
    }
if (CommTimeOut > 200)
    {
    CommTimeOut = 201;
    SerialPointer = 0;
    }
}
