//******************************************************************************
//  Jose I Quinones
//  Texas Instruments Inc.
//  July 2010
//  Built with IAR Embedded Workbench Version: 3.42A
//******************************************************************************
#include "Config.h"

#pragma vector=DACDMA_VECTOR
__interrupt void DigitalToAnalog_DMA(void)
{

}

#pragma vector=PORT2_VECTOR
__interrupt void Port2_Change(void)
{

}

#pragma vector=USART1TX_VECTOR
__interrupt void USART1_Transmit(void)
{

}

#pragma vector=USART1RX_VECTOR
__interrupt void USART1_Receive(void)
{

}

#pragma vector=PORT1_VECTOR
__interrupt void PORT1_Change(void)
{

}

#pragma vector=TIMERA1_VECTOR
__interrupt void TimerA1(void)
{

switch (TAIV)
{
case TACCR1_CCIFG_SET:
  break;
case TACCR2_CCIFG_SET:
  break;
case TAIFG_SET:
  break;
}

}

#pragma vector=ADC12_VECTOR
__interrupt void AnalogToDigitalConverter(void)
{

}

#pragma vector=WDT_VECTOR
__interrupt void Watchdog_Timer(void)
{

}

#pragma vector=COMPARATORA_VECTOR
__interrupt void ComparatorA(void)
{

}

#pragma vector=TIMERB1_VECTOR
__interrupt void TimerB1(void)
{
switch (TBIV)
{
case TBCCR1_CCIFG_SET:
  break;
case TBCCR2_CCIFG_SET:
  break;
case TBCCR3_CCIFG_SET:
  break;
case TBCCR4_CCIFG_SET:
  break;
case TBCCR5_CCIFG_SET:
  break;
case TBCCR6_CCIFG_SET:
  break;
case TBIFG_SET:
  break;
}
}

#pragma vector=TIMERB0_VECTOR
__interrupt void TimerB0(void)
{
}

#pragma vector=NMI_VECTOR
__interrupt void NonMaskableInterrupt(void)
{

}

