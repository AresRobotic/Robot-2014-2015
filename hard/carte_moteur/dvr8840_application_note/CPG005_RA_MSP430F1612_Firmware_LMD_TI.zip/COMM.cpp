//******************************************************************************
//  Jose I Quinones
//  Texas Instruments Inc.
//  July 2010
//  Built with IAR Embedded Workbench Version: 3.42A
//******************************************************************************
#include "Config.h"

char SerialPointer;
char SerialBuffer[SERIAL_BUFFER_LENGTH];
char SerialOutBuffer[3];
char SerialOutPointer;
bool MessageComplete;
int  CommTimeOut;

#pragma vector=USART0TX_VECTOR
__interrupt void USART0_Transmit(void)
{
SerialOutPointer += 1;
TXBUF0 = SerialOutBuffer[SerialOutPointer];
if (SerialOutPointer == SERIAL_OUT_LENGTH - 1)
    {
    IE1 &= ~UTXIE0;
    }
}

#pragma vector=USART0RX_VECTOR
__interrupt void USART0_Receive(void)
{
SerialBuffer[SerialPointer] = RXBUF0;
SerialPointer += 1;
CommTimeOut = 0;
if (SerialPointer == SERIAL_BUFFER_LENGTH)
    {
    SerialPointer = 0;
    MessageComplete = true;
    }
}
